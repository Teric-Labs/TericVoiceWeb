import React from "react";
import { Box } from "@mui/material";
import HistoryComponent from "../components/History";

const History = () => {
  return (
    <Box>
      <HistoryComponent />
    </Box>
  );
};

export default History;
