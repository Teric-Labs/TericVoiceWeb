const TextToSpeechEndpoints ={
    English:"https://api-inference.huggingface.co/models/facebook/mms-tts-eng",
    Luganda:"https://api-inference.huggingface.co/models/facebook/mms-tts-eng",
    Runyankore:"https://api-inference.huggingface.co/models/facebook/mms-tts-eng"
}
export default TextToSpeechEndpoints;