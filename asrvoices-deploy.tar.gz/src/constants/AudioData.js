const AudioData = [
    {
      id: 1,
      name: "Audio File 1",
      date: "2022-02-01",
    },
    {
      id: 2,
      name: "Audio File 2",
      date: "2022-02-02",
    },
    {
      id: 3,
      name: "Audio File 3",
      date: "2022-02-03",
    },
    {
      id: 4,
      name: "Audio File 4",
      date: "2022-02-04",
    },
    {
      id: 5,
      name: "Audio File 5",
      date: "2022-02-05",
    },
    {
      id: 6,
      name: "Audio File 6",
      date: "2022-02-06",
    },
    {
      id: 7,
      name: "Audio File 7",
      date: "2022-02-07",
    },
    {
      id: 8,
      name: "Audio File 8",
      date: "2022-02-08",
    },
    {
      id: 9,
      name: "Audio File 9",
      date: "2022-02-09",
    },
    {
      id: 10,
      name: "Audio File 10",
      date: "2022-02-10",
    },
  ];
  
  export default AudioData;
  